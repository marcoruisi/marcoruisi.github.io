=== MRC Before / After Shortcode ===
Contributors: mrc
Tags: before after, image comparison, slider
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 2.1.0
License: GPLv2 or later

A lightweight before/after image comparison shortcode with pointer and keyboard controls.

== Description ==

Use:

[before_after before="https://example.com/before.jpg" after="https://example.com/after.jpg"]

Optional attributes:

* start="50" — initial divider position from 0 to 100
* radius="14" — corner radius in pixels
* animate="yes" — short intro motion; respects reduced-motion preference
* class="" — custom CSS class
* alt="" — alt text for the base image
* label="" — accessible label for the slider control

The slider supports mouse, touch/pointer input and keyboard arrows, Home and End.

== Changelog ==

= 2.1.0 =
* Added keyboard-accessible slider semantics.
* Added reduced-motion handling.
* Switched to pointer events.
* Added GPL header and public release cleanup.

= 2.0.0 =
* Internal version.
