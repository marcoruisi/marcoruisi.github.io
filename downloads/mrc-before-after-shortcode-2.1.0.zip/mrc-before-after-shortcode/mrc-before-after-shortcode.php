<?php
/**
 * Plugin Name: MRC Before / After Shortcode
 * Description: Lightweight, keyboard-accessible before/after image comparison shortcode.
 * Version: 2.1.0
 * Author: MRC
 * License: GPL-2.0-or-later
 * Text Domain: mrc-before-after
 */

defined( 'ABSPATH' ) || exit;

final class MRC_Before_After_Shortcode {
    private static $assets_needed = false;
    private static $count = 0;

    public function __construct() {
        add_shortcode( 'before_after', array( $this, 'shortcode' ) );
        add_action( 'wp_footer', array( $this, 'assets' ), 99 );
    }

    public function shortcode( $atts ) {
        $atts = shortcode_atts(
            array(
                'before'  => '',
                'after'   => '',
                'start'   => '50',
                'radius'  => '14',
                'animate' => 'yes',
                'class'   => '',
                'alt'     => '',
                'label'   => __( 'Before and after image comparison', 'mrc-before-after' ),
            ),
            $atts,
            'before_after'
        );

        if ( empty( $atts['before'] ) || empty( $atts['after'] ) ) {
            return '';
        }

        self::$assets_needed = true;
        self::$count++;

        $id      = 'mrc-ba-' . self::$count;
        $start   = max( 0, min( 100, intval( $atts['start'] ) ) );
        $radius  = max( 0, intval( $atts['radius'] ) );
        $animate = strtolower( $atts['animate'] ) === 'no' ? '0' : '1';
        $classes = 'mrc-ba-slider';

        if ( ! empty( $atts['class'] ) ) {
            $classes .= ' ' . sanitize_html_class( $atts['class'] );
        }

        ob_start();
        ?>
        <div id="<?php echo esc_attr( $id ); ?>"
             class="<?php echo esc_attr( $classes ); ?>"
             data-start="<?php echo esc_attr( $start ); ?>"
             data-animate="<?php echo esc_attr( $animate ); ?>"
             style="--mrc-ba-radius:<?php echo esc_attr( $radius ); ?>px;">
            <div class="mrc-ba-stage">
                <img class="mrc-ba-before"
                     src="<?php echo esc_url( $atts['before'] ); ?>"
                     alt="<?php echo esc_attr( $atts['alt'] ); ?>"
                     loading="lazy"
                     draggable="false">
                <img class="mrc-ba-after"
                     src="<?php echo esc_url( $atts['after'] ); ?>"
                     alt=""
                     aria-hidden="true"
                     loading="lazy"
                     draggable="false">
                <div class="mrc-ba-divider"
                     role="slider"
                     tabindex="0"
                     aria-label="<?php echo esc_attr( $atts['label'] ); ?>"
                     aria-valuemin="0"
                     aria-valuemax="100"
                     aria-valuenow="<?php echo esc_attr( $start ); ?>">
                    <span class="mrc-ba-handle" aria-hidden="true"></span>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function assets() {
        if ( ! self::$assets_needed ) {
            return;
        }
        ?>
        <style>
        .mrc-ba-slider{position:relative;width:100%;overflow:hidden;border:1px solid rgba(0,0,0,.12);border-radius:var(--mrc-ba-radius,14px);background:#f5f5f5;user-select:none;-webkit-user-select:none;touch-action:none;margin-bottom:24px}
        .mrc-ba-stage{position:relative;width:100%;line-height:0}
        .mrc-ba-before{display:block;width:100%;height:auto;position:relative;z-index:1;pointer-events:none;-webkit-user-drag:none}
        .mrc-ba-after{position:absolute;inset:0;width:100%;height:100%;object-fit:fill;z-index:2;clip-path:inset(0 50% 0 0);pointer-events:none;-webkit-user-drag:none;will-change:clip-path}
        .mrc-ba-divider{position:absolute;top:0;bottom:0;left:50%;width:2px;background:#fff;transform:translateX(-50%);z-index:3;box-shadow:0 0 0 1px rgba(0,0,0,.08);cursor:ew-resize}
        .mrc-ba-divider:focus-visible{outline:3px solid currentColor;outline-offset:3px}
        .mrc-ba-handle{position:absolute;top:50%;left:50%;width:46px;height:46px;border-radius:999px;background:#fff;border:1px solid rgba(0,0,0,.10);transform:translate(-50%,-50%);box-shadow:0 6px 18px rgba(0,0,0,.18)}
        .mrc-ba-handle:before,.mrc-ba-handle:after{content:"";position:absolute;top:50%;width:9px;height:9px;border-top:2px solid #333;border-right:2px solid #333}
        .mrc-ba-handle:before{left:13px;transform:translateY(-50%) rotate(-135deg)}
        .mrc-ba-handle:after{right:13px;transform:translateY(-50%) rotate(45deg)}
        .mrc-ba-slider.mrc-ba-animating .mrc-ba-after{transition:clip-path 1.1s ease}
        .mrc-ba-slider.mrc-ba-animating .mrc-ba-divider{transition:left 1.1s ease}
        @media (prefers-reduced-motion:reduce){.mrc-ba-slider.mrc-ba-animating .mrc-ba-after,.mrc-ba-slider.mrc-ba-animating .mrc-ba-divider{transition:none}}
        </style>
        <script>
        (function(){
            function initOne(slider){
                if(!slider || slider.dataset.mrcBaInit==='1') return;
                slider.dataset.mrcBaInit='1';

                var after=slider.querySelector('.mrc-ba-after');
                var divider=slider.querySelector('.mrc-ba-divider');
                if(!after || !divider) return;

                var dragging=false;
                var animated=false;
                var start=parseInt(slider.getAttribute('data-start')||'50',10);
                if(isNaN(start)) start=50;
                start=Math.max(0,Math.min(100,start));

                function setPercent(percent){
                    percent=Math.max(0,Math.min(100,percent));
                    after.style.clipPath='inset(0 '+(100-percent)+'% 0 0)';
                    divider.style.left=percent+'%';
                    divider.setAttribute('aria-valuenow',Math.round(percent));
                }

                function fromClientX(x){
                    var rect=slider.getBoundingClientRect();
                    if(!rect.width) return;
                    setPercent(((x-rect.left)/rect.width)*100);
                }

                slider.addEventListener('pointerdown',function(e){
                    dragging=true;
                    slider.classList.remove('mrc-ba-animating');
                    slider.setPointerCapture && slider.setPointerCapture(e.pointerId);
                    fromClientX(e.clientX);
                });
                slider.addEventListener('pointermove',function(e){ if(dragging) fromClientX(e.clientX); });
                slider.addEventListener('pointerup',function(){ dragging=false; });
                slider.addEventListener('pointercancel',function(){ dragging=false; });

                divider.addEventListener('keydown',function(e){
                    var current=parseInt(divider.getAttribute('aria-valuenow')||start,10);
                    var next=current;
                    if(e.key==='ArrowLeft' || e.key==='ArrowDown') next=current-2;
                    else if(e.key==='ArrowRight' || e.key==='ArrowUp') next=current+2;
                    else if(e.key==='Home') next=0;
                    else if(e.key==='End') next=100;
                    else return;
                    e.preventDefault();
                    slider.classList.remove('mrc-ba-animating');
                    setPercent(next);
                });

                setPercent(start);

                var reduce=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                function intro(){
                    if(animated || reduce || slider.getAttribute('data-animate')!=='1') return;
                    animated=true;
                    slider.classList.add('mrc-ba-animating');
                    setPercent(35);
                    setTimeout(function(){setPercent(65)},100);
                    setTimeout(function(){setPercent(start)},1300);
                    setTimeout(function(){slider.classList.remove('mrc-ba-animating')},2400);
                }

                if('IntersectionObserver' in window){
                    var observer=new IntersectionObserver(function(entries){
                        entries.forEach(function(entry){
                            if(entry.isIntersecting){intro();observer.unobserve(slider)}
                        });
                    },{threshold:.35});
                    observer.observe(slider);
                }else{
                    intro();
                }
            }

            function initAll(){document.querySelectorAll('.mrc-ba-slider').forEach(initOne)}
            if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initAll);
            else initAll();
            window.addEventListener('load',initAll);
        })();
        </script>
        <?php
    }
}

new MRC_Before_After_Shortcode();
