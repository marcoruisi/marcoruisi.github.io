<?php
/**
 * Plugin Name: MRC GF Debug
 * Description: Targeted Gravity Forms validation debugging for administrators, without persistent logs.
 * Version: 1.1.0
 * Author: MRC
 * License: GPL-2.0-or-later
 * Text Domain: mrc-gf-debug
 */

defined( 'ABSPATH' ) || exit;

final class MRC_GF_Debug {
    const OPTION_KEY = 'mrc_gf_debug_settings';
    const MENU_SLUG  = 'mrc-gf-debug';

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        add_action( 'admin_notices', array( __CLASS__, 'dependency_notice' ) );

        add_filter( 'gform_validation', array( __CLASS__, 'capture_validation' ), 9999 );
        add_filter( 'gform_validation_message', array( __CLASS__, 'append_debug_message' ), 9999, 2 );
    }

    public static function defaults() {
        return array(
            'enabled'     => 0,
            'form_id'     => '',
            'show_values' => 0,
        );
    }

    public static function settings() {
        return wp_parse_args( (array) get_option( self::OPTION_KEY, array() ), self::defaults() );
    }

    public static function dependency_notice() {
        if ( ! current_user_can( 'manage_options' ) || class_exists( 'GFForms' ) ) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>MRC GF Debug:</strong> Gravity Forms is required.</p></div>';
    }

    public static function register_settings() {
        register_setting(
            'mrc_gf_debug_group',
            self::OPTION_KEY,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
                'default'           => self::defaults(),
            )
        );
    }

    public static function sanitize_settings( $input ) {
        $input = is_array( $input ) ? $input : array();

        return array(
            'enabled'     => empty( $input['enabled'] ) ? 0 : 1,
            'form_id'     => isset( $input['form_id'] ) ? absint( $input['form_id'] ) : '',
            'show_values' => empty( $input['show_values'] ) ? 0 : 1,
        );
    }

    public static function admin_menu() {
        add_management_page(
            'MRC GF Debug',
            'MRC GF Debug',
            'manage_options',
            self::MENU_SLUG,
            array( __CLASS__, 'render_settings_page' )
        );
    }

    public static function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $settings = self::settings();
        ?>
        <div class="wrap">
            <h1>MRC GF Debug</h1>
            <p><?php esc_html_e( 'Shows Gravity Forms validation failures directly above the form to administrators.', 'mrc-gf-debug' ); ?></p>

            <form method="post" action="options.php">
                <?php settings_fields( 'mrc_gf_debug_group' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Debug', 'mrc-gf-debug' ); ?></th>
                        <td><label>
                            <input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[enabled]" value="1" <?php checked( $settings['enabled'], 1 ); ?>>
                            <?php esc_html_e( 'Enable Gravity Forms debugging', 'mrc-gf-debug' ); ?>
                        </label></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="mrc-gf-debug-form-id"><?php esc_html_e( 'Form ID', 'mrc-gf-debug' ); ?></label></th>
                        <td>
                            <input id="mrc-gf-debug-form-id" type="number" min="1" class="small-text"
                                   name="<?php echo esc_attr( self::OPTION_KEY ); ?>[form_id]"
                                   value="<?php echo esc_attr( $settings['form_id'] ); ?>">
                            <p class="description"><?php esc_html_e( 'Leave empty to inspect all Gravity Forms.', 'mrc-gf-debug' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Submitted values', 'mrc-gf-debug' ); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[show_values]" value="1" <?php checked( $settings['show_values'], 1 ); ?>>
                                <?php esc_html_e( 'Show the submitted value for failed fields', 'mrc-gf-debug' ); ?>
                            </label>
                            <p class="description"><?php esc_html_e( 'Off by default. Enable only when needed; submitted values may contain sensitive data.', 'mrc-gf-debug' ); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    private static function is_debug_active_for_form( $form_id ) {
        if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) || ! class_exists( 'GFForms' ) ) {
            return false;
        }

        $settings = self::settings();

        if ( empty( $settings['enabled'] ) ) {
            return false;
        }

        return empty( $settings['form_id'] ) || (int) $settings['form_id'] === (int) $form_id;
    }

    public static function capture_validation( $validation_result ) {
        if ( empty( $validation_result['form'] ) || ! is_array( $validation_result['form'] ) ) {
            return $validation_result;
        }

        $form    = $validation_result['form'];
        $form_id = isset( $form['id'] ) ? (int) $form['id'] : 0;

        if ( ! $form_id || ! self::is_debug_active_for_form( $form_id ) ) {
            return $validation_result;
        }

        if ( ! empty( $validation_result['is_valid'] ) ) {
            unset( $GLOBALS[ 'mrc_gf_debug_errors_' . $form_id ] );
            return $validation_result;
        }

        $errors   = array();
        $settings = self::settings();

        foreach ( $form['fields'] as $field ) {
            if ( empty( $field->failed_validation ) ) {
                continue;
            }

            $errors[] = array(
                'id'      => $field->id,
                'label'   => (string) $field->label,
                'type'    => (string) $field->type,
                'message' => (string) $field->validation_message,
                'value'   => ! empty( $settings['show_values'] ) ? self::get_submitted_value( $field ) : null,
            );
        }

        if ( ! $errors ) {
            $errors[] = array(
                'id'      => '-',
                'label'   => __( 'No field marked failed_validation', 'mrc-gf-debug' ),
                'type'    => 'form',
                'message' => __( 'Gravity Forms considers the form invalid, but no field exposes failed_validation. Check custom form-level validation hooks.', 'mrc-gf-debug' ),
                'value'   => null,
            );
        }

        $GLOBALS[ 'mrc_gf_debug_errors_' . $form_id ] = $errors;
        return $validation_result;
    }

    private static function get_submitted_value( $field ) {
        if ( ! class_exists( 'GFFormsModel' ) ) {
            return '';
        }

        try {
            $value = GFFormsModel::get_field_value( $field );
        } catch ( Throwable $e ) {
            return '[Error reading value]';
        }

        if ( is_array( $value ) || is_object( $value ) ) {
            return wp_json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        }

        if ( null === $value ) {
            return 'NULL';
        }

        return '' === $value ? '[empty]' : (string) $value;
    }

    public static function append_debug_message( $message, $form ) {
        $form_id = isset( $form['id'] ) ? (int) $form['id'] : 0;

        if ( ! $form_id || ! self::is_debug_active_for_form( $form_id ) ) {
            return $message;
        }

        $errors = isset( $GLOBALS[ 'mrc_gf_debug_errors_' . $form_id ] )
            ? $GLOBALS[ 'mrc_gf_debug_errors_' . $form_id ]
            : array();

        if ( ! $errors ) {
            return $message;
        }

        $settings = self::settings();
        $html  = '<div class="mrc-gf-debug-box" style="margin:16px 0;padding:16px;border:2px solid #d63638;background:#fff;color:#1d2327;font-size:14px;line-height:1.45;">';
        $html .= '<strong style="display:block;margin-bottom:10px;color:#b32d2e;">MRC GF Debug - Form ' . esc_html( $form_id ) . '</strong>';
        $html .= '<table style="width:100%;border-collapse:collapse;"><thead><tr>';
        foreach ( array( 'ID', __( 'Field', 'mrc-gf-debug' ), __( 'Type', 'mrc-gf-debug' ), __( 'Error', 'mrc-gf-debug' ) ) as $heading ) {
            $html .= '<th style="text-align:left;padding:6px;border-bottom:1px solid #ccd0d4;">' . esc_html( $heading ) . '</th>';
        }
        if ( ! empty( $settings['show_values'] ) ) {
            $html .= '<th style="text-align:left;padding:6px;border-bottom:1px solid #ccd0d4;">' . esc_html__( 'Submitted value', 'mrc-gf-debug' ) . '</th>';
        }
        $html .= '</tr></thead><tbody>';

        foreach ( $errors as $error ) {
            $html .= '<tr>';
            $html .= '<td style="vertical-align:top;padding:6px;border-bottom:1px solid #eee;"><code>' . esc_html( $error['id'] ) . '</code></td>';
            $html .= '<td style="vertical-align:top;padding:6px;border-bottom:1px solid #eee;">' . esc_html( $error['label'] ) . '</td>';
            $html .= '<td style="vertical-align:top;padding:6px;border-bottom:1px solid #eee;"><code>' . esc_html( $error['type'] ) . '</code></td>';
            $html .= '<td style="vertical-align:top;padding:6px;border-bottom:1px solid #eee;">' . esc_html( $error['message'] ?: __( '[no specific message]', 'mrc-gf-debug' ) ) . '</td>';
            if ( ! empty( $settings['show_values'] ) ) {
                $html .= '<td style="vertical-align:top;padding:6px;border-bottom:1px solid #eee;max-width:420px;word-break:break-word;"><code>' . esc_html( (string) $error['value'] ) . '</code></td>';
            }
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';
        $html .= '<p style="margin:10px 0 0;color:#646970;"><em>' . esc_html__( 'Visible only to users with manage_options.', 'mrc-gf-debug' ) . '</em></p>';
        $html .= '</div>';

        return $message . $html;
    }
}

MRC_GF_Debug::init();
