=== MRC GF Debug ===
Contributors: mrc
Tags: gravity forms, debug, validation
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

Targeted Gravity Forms validation debugging for administrators, without persistent logs.

== Description ==

MRC GF Debug helps identify which Gravity Forms fields fail validation.

* Tools > MRC GF Debug settings page
* optional form ID filter
* errors displayed directly above the form
* visible only to users with manage_options
* submitted values are OFF by default
* no wp-config.php changes
* no persistent log file

Requires Gravity Forms.

== Installation ==

1. Upload and activate the plugin.
2. Open Tools > MRC GF Debug.
3. Enable debugging.
4. Optionally enter a form ID.
5. Reproduce the validation failure while logged in as an administrator.
6. Disable debugging when finished.

== Changelog ==

= 1.1.0 =
* Public release cleanup.
* Added Gravity Forms dependency notice.
* Submitted values are now hidden by default.
* Added GPL header and safer public-facing strings.

= 1.0.0 =
* Initial internal version.
